#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "5d872d3ee"     # abbreviated commit hash
commit = "5d872d3ee5cc4d963dcf695ac6638bc9b974a2ff"  # commit hash
date = "2019-06-19 11:36:07 +0200"   # commit date
author = "Thomas Robitaille <thomas.robitaille@gmail.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Hooks: Make notebook hook look paths reported by jupyter_core.

Also only include directories that actually exist."""
